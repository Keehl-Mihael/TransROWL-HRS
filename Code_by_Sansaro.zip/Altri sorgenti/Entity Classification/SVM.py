#Import scikit-learn dataset library
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import balanced_accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import numpy as np
from sklearn.model_selection import KFold


from sklearn.multiclass import OneVsRestClassifier
#Reading dataset
dataset = pd.read_csv('/home/jhonny/Scrivania/Dataset/transowl.csv')

dataset = dataset.sample(n=2000)

# creating input features and target variables
X= dataset.iloc[:,0:100]
y1= dataset.iloc[:,100:101]
# y2= dataset.iloc[:,101:102]
# y3= dataset.iloc[:,102:103]
# y4= dataset.iloc[:,103:104]

# y_tot = [y1,y2,y3,y4]
y_tot = [y1]

y_i = 0
 
model = OneVsRestClassifier(SVC(C=0.1, cache_size=200, class_weight=None, coef0=0.0,
    decision_function_shape='ovr', degree=3, gamma='scale', kernel='rbf',
    max_iter=-1, probability=False, random_state=None, shrinking=True,
    tol=0.001, verbose=False))

yi = 0

match = []
omission = []
commission = []
induction = []

for y in y_tot:
    #print(yi)
    yi = yi+1
    #print(y_i)
    accuracy = []
    y_i = y_i + 1;
    kf = KFold(n_splits=10)
    KFold(n_splits=10, random_state=None, shuffle=False)
    fold = 1
    for train_index, test_index in kf.split(X):   
        print(yi,"Fold:",fold)
        fold = fold+1
        X_train, X_test = X.iloc[train_index], X.iloc[test_index]
        y_train, y_test = y.iloc[train_index], y.iloc[test_index]
        #fit model with training data
        model.fit(X_train, y_train.values.ravel())
        #evaluation on test data
        pred = model.predict(X_test)
        
        accuracy.append(balanced_accuracy_score(y_test, pred))

        cm = confusion_matrix(y_test, pred, [1, 0, -1])
        
        match.append((cm[0][0] + cm[1][1] + cm[2][2]) / len(y_test))
        omission.append((cm[1][0] + cm[1][2])  / len(y_test))
        commission.append((cm[0][2] + cm[2][0]) / len(y_test))
        induction.append((cm[0][1] + cm[2][1]) / len(y_test))
        
print("Match: {:.3f} (+/- {:.3f})".format(np.mean(match), np.std(match)))
print("omission: {:.3f} (+/- {:.3f})".format(np.mean(omission),np.std(omission)))
print("commission: {:.3f} (+/- {:.3f})".format(np.mean(commission), np.std(commission)))
print("induction: {:.3f} (+/- {:.3f})".format(np.mean(induction),np.std(induction)))

