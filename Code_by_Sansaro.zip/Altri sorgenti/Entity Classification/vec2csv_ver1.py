import numpy as np
typeofId = 275
import csv

src = "/home/jhonny/Scrivania/DBPedia15K/Dataset/"
output = 'transowl_open.csv'

num_entities = 12862


types=[]
file_in = open('/home/jhonny/Scaricati/types15K_open.txt', 'r')
for line in file_in:
    x=line.split()
    first = True;
    type=[]
    for val in x:
        if(first):
            first = False
        else:
            type.append(val)
    types.append(type)

file_in = open(src + 'entity2vec_OWL.vec', 'r')
dataset = []
for line in file_in:
    x=line.split()
    example = []
    for val in x: 
        example.append(float(val))
    dataset.append(example)
    example = np.array(example)


labels = []
for i in range(0,len(dataset[0])):
    lbl = "DIM" + (i+1).__str__()
    labels.append(lbl)
classes = ["Agent","Place","Work"]   
labels.extend(classes) 
with open(src + output,'w') as temp:
    writer = csv.writer(temp, delimiter=',')
    writer.writerow(labels)
temp.close()


for i in range(num_entities):
    exp = dataset[i]
    exp.extend(types[i])
    with open(src + output,'a') as temp:
        writer = csv.writer(temp, delimiter=',')
        writer.writerow(exp)
    temp.close()
        
