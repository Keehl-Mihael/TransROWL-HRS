import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from keras import Sequential
from keras.layers import Dense
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.model_selection import KFold
from keras.utils import to_categorical


from keras import backend as K

def l1_reg(weight_matrix):
    return 0.01 * K.sum(K.abs(weight_matrix))


#Reading dataset
print("Loading dataset...")
dataset = pd.read_csv('transe.csv')


# creating input features and target variables
X= dataset.iloc[:,0:100]
y1= pd.get_dummies(dataset.iloc[:,100:101].astype(str)) #ISLAND
y2= pd.get_dummies(dataset.iloc[:,101:102].astype(str)) #governor
y3= pd.get_dummies(dataset.iloc[:,102:103].astype(str)) #economist


accuracy = []
macro_precision = []
macro_recall = []
macro_f1 = []
micro_precision = []
micro_recall = []
micro_f1 = []

y_tot = [y1,y2,y3]


#standardizing the input feature
sc = StandardScaler()
data = sc.fit_transform(X)

yn = 0
for y in y_tot:
    yn += 1
    kf = KFold(n_splits=10)
    KFold(n_splits=10, random_state=None, shuffle=False)
    f = 0
    for train_index, test_index in kf.split(X): 
        print(str(yn) + ") Fold [" + str(f) + "]")
        f += 1  
        X_train, X_test = X.iloc[train_index], X.iloc[test_index]
        y_train, y_test = y.iloc[train_index], y.iloc[test_index]

        #NN with 2 hidden layer
        classifier = Sequential()
        #First Hidden Layer
        classifier.add(Dense(54, activation='relu', kernel_initializer='random_normal', input_dim=100))
        #secondo layer riduce prestazioni
        classifier.add(Dense(54, activation='relu', kernel_initializer='random_normal',kernel_regularizer=l1_reg))
        #Output Layer
        classifier.add(Dense(3, activation='softmax', kernel_initializer='random_normal'))
        
        #Compiling the neural network
        classifier.compile(loss = 'categorical_crossentropy' , optimizer = 'Adagrad' , metrics = ['accuracy'] )
        
        #Fitting the data to the training dataset
        classifier.fit(X_train, y_train,  epochs = 200, batch_size = 50, verbose=0 )
        #loss value & metrics values
         
        pred = classifier.predict(X_test)
        pred=(pred>0.5)
        accuracy.append(accuracy_score(y_test, pred))
        
        macro_precision.append(precision_score(y_test, pred, average='macro'))
        macro_recall.append(recall_score(y_test, pred, average='macro'))
        macro_f1.append(f1_score(y_test, pred, average='macro'))
        
        micro_precision.append(precision_score(y_test, pred, average='micro'))
        micro_recall.append(recall_score(y_test, pred, average='micro'))
        micro_f1.append(f1_score(y_test, pred, average='micro'))
    
print("Accuracy: {:.4f}\nPrecision:\n- Macro: {:.4f}\n- Micro: {:.4f}\nRecall:\n- Macro: {:.4f}\n- Micro: {:.4f}\nF1-measure:\n- Macro: {:.4f}\n- Micro: {:.4f}".format(np.mean(accuracy), np.mean(macro_precision), np.mean(micro_precision), np.mean(macro_recall), np.mean(micro_recall), np.mean(macro_f1), np.mean(micro_f1)))
