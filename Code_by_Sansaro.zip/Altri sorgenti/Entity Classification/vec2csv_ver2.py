import numpy as np
import csv

src = "/home/jhonny/Scrivania/DBPedia100K/Dataset/"
output = 'transowl_person.csv'

num_entities = 100171

#ritrovare il valore delta per ogni relazione r
types= dict()
file_in = open('/home/jhonny/Scaricati/person.txt', 'r')
for line in file_in:
    x=line.split()
    first = True;
    typ=[]
    name = ""
    for val in x:
        if(first):
            name = ('<' + val + '>')
            first = False
        else:
            typ.append(val)
    types[name] = typ


new_types = dict()
file_in = open('/home/jhonny/Scrivania/DBPedia100K/Dataset/entity2id.txt', 'r')
for line in file_in:
    x=line.split()
    ent=[]
    for val in x:
        ent.append(val)
    if(types.get(ent[0]) != None):
        new_types[int(ent[1])] = types.get(ent[0])


file_in = open('/home/jhonny/Scrivania/DBPedia100K/Dataset/entity2vec_OWL.vec', 'r')
dataset = []
for line in file_in:
    x=line.split()
    example = []
    for val in x: 
        example.append(float(val))
    dataset.append(example)


labels = []
for i in range(0,len(dataset[0])):
    lbl = "DIM" + (i+1).__str__()
    labels.append(lbl)
#classes = ["Event","Artist","Athlete","Place"]
classes = ["Person"]

labels.extend(classes) 
with open(src + output,'w') as temp:
    writer = csv.writer(temp, delimiter=',')
    writer.writerow(labels)
temp.close()


for i in range(num_entities):
    if(new_types.get(i) != None):
        exp = dataset[i]
        exp.extend(new_types.get(i))
        with open(src + output,'a') as temp:
            writer = csv.writer(temp, delimiter=',')
            writer.writerow(exp)
        temp.close()


    