import org.apache.jena.base.Sys;
import org.apache.jena.ext.com.google.common.collect.ArrayListMultimap;
import org.apache.jena.ext.com.google.common.collect.Multimap;
import org.apache.jena.rdf.model.*;
import org.apache.jena.reasoner.Derivation;
import org.apache.jena.reasoner.Reasoner;
import org.apache.jena.reasoner.ReasonerRegistry;
import org.apache.jena.reasoner.ValidityReport;
import org.apache.jena.util.FileManager;
import org.apache.jena.util.PrintUtil;
import org.apache.jena.vocabulary.OWL;
import org.apache.jena.vocabulary.OWL2;
import org.apache.jena.vocabulary.RDF;
import org.apache.jena.vocabulary.RDFS;

import java.io.*;
import java.util.*;

public class reasoner {
    Model schema;
    Model data;
    InfModel infmodel;
    Reasoner reasoner;

    reasoner() throws FileNotFoundException {
        schema = FileManager.get().loadModel("src\\main\\resources\\dbpedia.owl");
        System.out.println("Schema created");
        data = ModelFactory.createDefaultModel();
        System.out.println("Data Loaded");
        data.read(new FileInputStream(new File("src\\main\\resources\\dbp100_type.ttl")),null,"TURTLE");
        reasoner = ReasonerRegistry.getOWLReasoner();
        reasoner = reasoner.bindSchema(schema);
        infmodel = ModelFactory.createInfModel(reasoner, data);
        System.out.println("Model created");
    }

    private void printStatements(Model m, Resource s, Property p, Resource o) {
        for (StmtIterator i = m.listStatements(s,p,o); i.hasNext(); ) {
            Statement stmt = i.nextStatement();
            System.out.println(" - " + PrintUtil.print(stmt));
        }
    }

    public ArrayList<Statement> getStatements(Model m, Resource s, Property p, Resource o) {
        ArrayList<Statement> list = new ArrayList<Statement>();
        for (StmtIterator i = m.listStatements(s,p,o); i.hasNext(); ) {
            list.add(i.nextStatement());
        }
        return list;
    }

    public void rangeDomain() {
        HashSet<Resource> cls_set = new HashSet<Resource>();
        ArrayList<Statement> ls = getStatements(data, null, RDF.type, null);
        for(Statement i : ls) {
            Resource cls = i.getObject().asResource();
            cls_set.add(cls);
        }

        HashSet<Property> p_set = new HashSet<Property>();
        for (StmtIterator i = data.listStatements(); i.hasNext(); ) {
            Property p =  i.nextStatement().getPredicate();
            p_set.add(p);
        }

        ArrayList<String> ranges = new ArrayList<String>();
        ArrayList<String> domains = new ArrayList<String>();
        int count = 0;
        for(Iterator<Property> i = p_set.iterator(); i.hasNext(); ) {
            Property p = i.next();
            float perc = (float) count++/p_set.size();
            System.out.println(p + " " + perc);
            //System.out.println("RANGE");
            ArrayList<Statement> l = getStatements(schema, p, RDFS.range, null);
            for (Statement t : l) {
                Resource range = t.getObject().asResource();

                ArrayList<Statement> sub_range = getStatements(infmodel, null, RDFS.subClassOf, range);
                for (Statement tmp : sub_range) {
                    if (cls_set.contains(tmp.getSubject())) {
                        System.out.println(p.getLocalName() + " RANGE " + tmp.getSubject().getLocalName());
                        ranges.add(p.getURI() + "\t" + tmp.getSubject().getURI());
                    }
                }
            }

            l = getStatements(schema, p, RDFS.domain, null);
            for (Statement t : l) {
                Resource range = t.getObject().asResource();
                ArrayList<Statement> sub_domain = getStatements(infmodel, null, RDFS.subClassOf, range);
                for (Statement tmp : sub_domain) {
                    if (cls_set.contains(tmp.getSubject())) {
                        System.out.println(p.getLocalName() + " DOMAIN " + tmp.getSubject().getLocalName());
                        domains.add(p.getURI() + "\t" + tmp.getSubject().getURI());
                    }
                }
            }
        }
        try {
            FileOutputStream fos = new FileOutputStream("ranges.ser");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(ranges);
            oos.close();
            fos.close();
            System.out.println("Serialized HashMap data is saved in ranges.ser");
        }catch(IOException ioe) {
            ioe.printStackTrace();
        }
        try {
            FileOutputStream fos = new FileOutputStream("domains.ser");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(domains);
            oos.close();
            fos.close();
            System.out.println("Serialized HashMap data is saved in domains.ser");
        }catch(IOException ioe) {
            ioe.printStackTrace();
        }
    }

    public void generateDisjointClass() {
        HashSet<Resource> cls_set = new HashSet<Resource>();
        ArrayList<Statement> l = getStatements(data, null, RDF.type, null);
        for(Statement i : l) {
            Resource cls = i.getObject().asResource();
            cls_set.add(cls);
        }
        ArrayList<String> clsToDisj = new ArrayList<String>();
        int count = 0;
        for( Iterator<Resource> i = cls_set.iterator(); i.hasNext(); ) {
            Resource next = i.next();
            float perc = (float) ++count/cls_set.size();
            System.out.println(next.getURI() + " " + perc);
            for(Statement t : getStatements(infmodel, next, OWL.disjointWith, null)) {
                Resource disj = t.getObject().asResource();
                for(Statement t2 : getStatements(infmodel, null, RDFS.subClassOf, disj)) {
                    Resource sub_disj = t2.getSubject();
                    if(cls_set.contains(sub_disj)) {
                        System.out.println("\t" + next.getLocalName() + " DisjointWith " + sub_disj.getLocalName());
                        String s = next.getURI() + "\t" + sub_disj.getURI();
                        clsToDisj.add(s);
                    }
                }
            }
        }
        try {
            FileOutputStream fos = new FileOutputStream("disjoint.ser");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(clsToDisj);
            oos.close();
            fos.close();
            System.out.println("Serialized HashMap data is saved in hashmap.ser");
        }catch(IOException ioe) {
            ioe.printStackTrace();
        }
    }

    public void corruptClass() {
        Multimap<String, String> disj_map = ArrayListMultimap.create();
        for(String in : openSerial("disjoint.ser")) {
            Scanner s = new Scanner(in).useDelimiter("\t");
            disj_map.put(s.next(),s.next());
        }

        ArrayList<String> out = new ArrayList<String>();
        ArrayList<Statement> ls = getStatements(data, null, RDF.type, null);
        for(Statement i : ls) {
            Resource cls = i.getObject().asResource();
            for (String s : disj_map.get(cls.getURI())) {
                out.add("<" + i.getSubject() + "> <" + i.getPredicate() + "> <" + s + ">");
            }
        }

        try {
            saveList(out,"corruptTypeOf.txt");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

    }

    private void print(Object s) {
        System.out.println(s);
    }

    private void saveList(List<String> out, String outName) throws FileNotFoundException, UnsupportedEncodingException {
        PrintWriter writer = new PrintWriter(outName, "UTF-8");
        for(String s : out) {
            writer.println(s);
        }
        writer.close();
        print("List saved on " + outName);
    }

    private ArrayList<String> openSerial(String name) {
        ArrayList<String> serialized = null;
        try {
            FileInputStream fis = new FileInputStream(name);
            ObjectInputStream ois = new ObjectInputStream(fis);
            serialized = (ArrayList) ois.readObject();
            ois.close();
            fis.close();
        }catch(IOException ioe) {
            ioe.printStackTrace();
        } catch(ClassNotFoundException c) {
            System.out.println("Class not found");
            c.printStackTrace();
        }
        System.out.println("Deserialized HashMap");
        return serialized;
    }

    public void getRangeDomainFromSer() {
        ArrayList<String> strings = openSerial("ranges.ser");
        ArrayList<String> strings1 = openSerial("domains.ser");

        ArrayList<String> range = new ArrayList<String>();
        ArrayList<String> domain = new ArrayList<String>();

        for(String s : strings) {
            Scanner sc = new Scanner(s).useDelimiter("\t");
            range.add("<" + sc.next() + ">\t<" + sc.next() + ">");
        }

        for(String s : strings1) {
            Scanner sc = new Scanner(s).useDelimiter("\t");
            domain.add("<" + sc.next() + ">\t<" + sc.next() + ">");
        }

        try {
            saveList(range, "rs_range.txt");
            saveList(domain, "rs_domain.txt");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    public void getInferClass() {
       /* data = data.remove(getStatements(data, null, RDF.type, null));
        print("Removed RDf.type");
        infmodel = ModelFactory.createInfModel(reasoner, data);
        System.out.println("Model created");*/

        BufferedReader reader;
        BufferedWriter writer_close,writer_open;
        ArrayList<String> res_l = new ArrayList<String>();
        try {
            reader = new BufferedReader(new FileReader("C:\\Users\\Giovanni\\IdeaProjects\\JavaReasoner\\src\\main\\resources\\entity100k.txt"));
            String line = reader.readLine();
            while (line != null) {
                String res = new StringTokenizer(line).nextToken();
                res_l.add(res.substring(1,(res.length()-1)));
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        print("shuffle");
        Collections.shuffle(res_l);

        Resource c1 = infmodel.getResource("http://dbpedia.org/ontology/Agent");
        Resource c2 = infmodel.getResource("http://dbpedia.org/ontology/Place");
        Resource c3 = infmodel.getResource("http://dbpedia.org/ontology/Work");
        int i = 0;
        try {
            writer_close = new BufferedWriter(new FileWriter("types100k_close.txt"));
            writer_open = new BufferedWriter(new FileWriter("types100k_open.txt"));

            writer_close.write(c1.getURI() + " " + c2.getURI() + " " + c3.getURI() + "\n");
            writer_open.write(c1.getURI() + " " + c2.getURI() + " " + c3.getURI() + "\n");

            for(String s : res_l) {
                i++;
                Resource r = infmodel.getResource(s);
                int num_c1 = getStatements(infmodel, r, RDF.type, c1).size();
                int num_c2 = getStatements(infmodel, r, RDF.type, c2).size();
                int num_c3 = getStatements(infmodel, r, RDF.type, c3).size();
                writer_close.write(s + "\t" + (num_c1) + "\t" + (num_c2) + "\t" + (num_c3) + "\n");

                if(num_c1 == 1)
                    num_c2 = -1;
                else if(num_c2 == 1)
                    num_c1 = -1;
                writer_open.write(s + "\t" + (num_c1) + "\t" + (num_c2) + "\t" + (num_c3) + "\n");

                print((float) i/res_l.size()*100);
                if(i > 20000)
                    break;
            }
            writer_open.close();
            writer_close.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void test2() throws FileNotFoundException {
        Resource event = infmodel.getResource("http://dbpedia.org/ontology/Event");
        Resource work = infmodel.getResource("http://dbpedia.org/ontology/Work");
        Resource artist = infmodel.getResource("http://dbpedia.org/ontology/Artist");
        Resource athlete = infmodel.getResource("http://dbpedia.org/ontology/Athlete");
        Resource place = infmodel.getResource("http://dbpedia.org/ontology/Place");

        ArrayList<Statement> statements;
        Set<Resource> subj = new HashSet<Resource>();

        statements = getStatements(infmodel, null, RDF.type, athlete);
        int i = 0;
        for (Statement st : statements) {
            if (i++ < 2000)
                subj.add(st.getSubject());
            else
                break;
        }
        print(subj.size());

        statements = getStatements(infmodel, null, RDF.type, artist);
        i = 0;
        for (Statement st : statements) {
            if (i++ < 2000)
                subj.add(st.getSubject());
            else
                break;
        }
        print(subj.size());

        statements = getStatements(infmodel, null, RDF.type, place);
        i = 0;
        for (Statement st : statements) {
            if (i++ < 2000)
                subj.add(st.getSubject());
            else
                break;
        }
        print(subj.size());

        statements = getStatements(infmodel, null, RDF.type, event);
        i = 0;
        for (Statement st : statements) {
            if (i++ < 2000)
                subj.add(st.getSubject());
            else
                break;
        }
        print(subj.size());
        statements = getStatements(infmodel, null, RDF.type, work);
        i = 0;
        for (Statement st : statements) {
            if (i++ < 1500)
                subj.add(st.getSubject());
            else
                break;
        }
        print(subj.size());

        BufferedWriter writer_open;
        i = 0;
        try {
            writer_open = new BufferedWriter(new FileWriter("dataset100k.txt"));

            for(Resource r : subj) {
                i++;
                int num_c1 = getStatements(data, r, RDF.type, event).size();
                int num_c2 = getStatements(data, r, RDF.type, work).size();
                int num_c3 = getStatements(data, r, RDF.type, artist).size();
                int num_c4 = getStatements(data, r, RDF.type, athlete).size();
                int num_c5 = getStatements(data, r, RDF.type, place).size();

                if((num_c3 + num_c4) > 0) {
                    num_c1 = -1;
                    num_c5 = -1;
                } else if((num_c1  + num_c5) > 0) {
                    num_c3 = -1;
                    num_c4 = -1;
                }

                writer_open.write(r.getURI() + "\t" + (num_c1) + "\t" + (num_c3) + "\t" + (num_c4) + "\t" + (num_c5) + "\n");

                print((float) i/subj.size()*100);
            }
            writer_open.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void test() throws FileNotFoundException {
        Resource artist = infmodel.getResource("http://dbpedia.org/ontology/Person");
        ArrayList<Resource> disj_artist = new ArrayList<Resource>();

        ArrayList<Statement> statements = getStatements(infmodel, artist, OWL.disjointWith, null);
        for(Statement st : statements) {
            disj_artist.add(st.getObject().asResource());
            print("Artist disjointWith " + st.getObject().asResource().getLocalName());
        }

        Set<Resource> subj = new HashSet<Resource>();

        BufferedReader reader;
        ArrayList<String> res_l = new ArrayList<String>();
        try {
            reader = new BufferedReader(new FileReader("C:\\Users\\Giovanni\\IdeaProjects\\JavaReasoner\\src\\main\\resources\\entity100k.txt"));
            String line = reader.readLine();
            while (line != null) {
                String res = new StringTokenizer(line).nextToken();
                res_l.add(res.substring(1,(res.length()-1)));
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        print("shuffle");
        Collections.shuffle(res_l);

        for (int i = 0; i < 10000; i++) {
            subj.add(data.getResource(res_l.get(i)));
        }

        BufferedWriter writer_open;
        int i = 0;
        try {
            writer_open = new BufferedWriter(new FileWriter("dataset100k.txt"));

            for(Resource r : subj) {
                i++;
                int is_artist = getStatements(infmodel, r, RDF.type, artist).size();

                for(Resource disj : disj_artist) {
                    int is_disj = getStatements(data, r, RDF.type, artist).size();
                    if(is_disj > 0) {
                        is_artist = -1;
                        break;
                    }
                }

                writer_open.write(r.getURI() + "\t" + (is_artist)+ "\n");

                print((float) i/subj.size()*100);
            }
            writer_open.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}