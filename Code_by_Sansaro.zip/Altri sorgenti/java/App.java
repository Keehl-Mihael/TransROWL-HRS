import java.io.FileNotFoundException;
import java.io.IOException;

import org.semanticweb.owlapi.model.OWLOntologyCreationException;
public class App 
{
	
    public static void main( String[] args )
    {
            String s = "src\\main\\resources\\triples.ttl";
            Ontology ont  = null;

            try {
    			ont = new Ontology(s);
    			//ont.getsubProperty();
              //  ont.getObjectRangeDomain();
            } catch (FileNotFoundException e) {
    			System.out.println("File non trovato:" + e.getMessage());
    		} catch (OWLOntologyCreationException e) {
    			System.out.println("Errore creazione ontologia:" + e.getMessage());
    		} catch (IOException e) {
                e.printStackTrace();
            }
    }
}
