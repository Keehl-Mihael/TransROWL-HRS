import java.io.FileNotFoundException;

public class main {

    public static void main (String[] args) throws FileNotFoundException {
        reasoner r = new reasoner();
//        r.rangeDomain();
//        r.generateDisjointClass();
//        r.corruptClass();
//        r.getRangeDomainFromSer();
       // r.getInferClass();
               r.test();
    }
}
