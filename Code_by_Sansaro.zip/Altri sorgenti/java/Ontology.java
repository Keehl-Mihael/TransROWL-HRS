import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.reasoner.Node;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.util.OWLOntologyWalker;
import org.semanticweb.owlapi.util.OWLOntologyWalkerVisitor;
import uk.ac.manchester.cs.jfact.JFactFactory;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.stream.Stream;


public class Ontology {
	private OWLOntology o;
	private OWLReasoner r;
	private OWLOntologyManager m;

	Ontology(String owlFileName) throws IOException, OWLOntologyCreationException {
    	m = OWLManager.createOWLOntologyManager();
		o = m.loadOntologyFromOntologyDocument(new FileInputStream("src\\main\\resources\\triples.ttl"));
		r = new JFactFactory().createReasoner(o);

		IRI i = IRI.create("http://dbpedia.org/ontology/Person");
		OWLClass cls = m.getOWLDataFactory().getOWLClass(i);
		Set<OWLNamedIndividual> artist = r.getInstances(cls, true).getFlattened();

		OWLDataFactory factory = OWLManager.getOWLDataFactory();
		Set<OWLNamedIndividual> not_artist = r.getInstances(cls.getComplementNNF(), true).getFlattened();

		System.out.println("True :" + artist.size() + " False: " + not_artist.size());

/*		Iterator<OWLNamedIndividual> iterator = o.individualsInSignature().iterator();
		BufferedWriter writer;
		writer = new BufferedWriter(new FileWriter("new_dataset15k.txt"));
		while(iterator.hasNext()) {
			OWLIndividual ind = iterator.next();
			//writer.write(ind + "\t" + (is_person)+ "\t" +  (is_settl)+  "\n");
		}*/

	}






	public void getDisjointClass() {
		Iterator<OWLClass> it = o.classesInSignature().iterator();
		int n = 0;
		HashSet<String> x = new HashSet<>();
		while(it.hasNext()) {
			OWLClass cls = it.next();
			Iterator<OWLDisjointClassesAxiom> equi = o.disjointClassesAxioms(cls).iterator();
			while(equi.hasNext()) {
				OWLDisjointClassesAxiom tmp = equi.next();
				Iterator<OWLClass> iterator = tmp.classesInSignature().iterator();
				String s = "";
				while(iterator.hasNext()) {
					OWLClass c = iterator.next();
					s += (c);
					if(iterator.hasNext())
						s+=("\t");
				}
				x.add(s);
			}
		}
		x.forEach(System.out::println);
	}

	public void getsubProperty() {
		Iterator<OWLDataProperty> it = o.dataPropertiesInSignature().iterator();
		while(it.hasNext()) {
			OWLDataProperty prop = it.next();
			Iterator<OWLSubDataPropertyOfAxiom> itt = o.dataSubPropertyAxiomsForSubProperty(prop).iterator();
			while(itt.hasNext()){
				OWLSubDataPropertyOfAxiom x = itt.next();
				System.out.println(x.getSubProperty() + "\t" + x.getSuperProperty());
			}

		}
	}

	public void getEquivalentClass() {
		Iterator<OWLClass> it = o.classesInSignature().iterator();
		int n = 0;
		HashSet<String> x = new HashSet<>();
		while(it.hasNext()) {
			OWLClass relation = it.next();
			Iterator<OWLEquivalentClassesAxiom> equi = o.equivalentClassesAxioms(relation).iterator();
			while(equi.hasNext()) {
				OWLEquivalentClassesAxiom tmp = equi.next();
				Iterator<OWLClass> iterator = tmp.classesInSignature().iterator();
				String s = "";
				while(iterator.hasNext()) {
					OWLClass c = iterator.next();
					s += (c);
					if(iterator.hasNext())
						s+=("\t");
				}
				x.add(s);
			}
		}
		x.forEach(System.out::println);
	}
	//stampa su file per ogni proprietà (tra oggetti) il range e il dominio (se disponibili)
	public void getObjectRangeDomain() {
		try {
			FileWriter rangeWriter = new FileWriter("src\\main\\resources\\res2range.txt");
			FileWriter domainWriter = new FileWriter("src\\main\\resources\\res2domain.txt");
			Iterator<OWLObjectProperty> it = o.objectPropertiesInSignature().iterator();
			while(it.hasNext()) {
				OWLObjectProperty relation = it.next();
	//			.forEach(System.out::println);
				Iterator<OWLObjectPropertyDomainAxiom> domain = o.objectPropertyDomainAxioms(relation).iterator();
				String str_range = "",str_domain = "";
				if(domain.hasNext()) {
					OWLObjectPropertyDomainAxiom next = domain.next();
					str_domain = (" " + next.getDomain().toString());
				}
				Iterator<OWLObjectPropertyRangeAxiom> range = o.objectPropertyRangeAxioms(relation).iterator();
				if(range.hasNext()) {
					OWLObjectPropertyRangeAxiom next = range.next();
					str_range = (" " + next.getRange().toString());
				}
				if(!str_range.equals("")) {
					rangeWriter.write(relation.toString() + str_range + "\n");
				}
				if(!str_domain.equals(""))
					domainWriter.write(relation.toString() + str_domain + "\n");
			}
			rangeWriter.close();
			domainWriter.close();
			System.out.println("Successfully wrote to the files.");
		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}

	//stampa su file l'elenco delle classi con un id generato proceduralmente
    public void getClasses() {
		try {
			FileWriter myWriter = new FileWriter("src\\main\\resources\\class2id.txt");
			int id = 0;
			Stream<OWLClass> stream = o.classesInSignature();
			Iterator<OWLClass> i = stream.iterator();
			while(i.hasNext()) {
				OWLClass owl_obj = i.next();
				myWriter.write(owl_obj + " " + id++ + "\n");
			}
			myWriter.close();
			System.out.println("Successfully wrote to the file.");
		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
    }
    
    public void OntWalker() {
    	// Create the walker
    	OWLOntologyWalker walker = new OWLOntologyWalker(Collections.singleton(o));
    	// Now ask our walker to walk over the ontology
    	OWLOntologyWalkerVisitor visitor = new OWLOntologyWalkerVisitor(walker) {
	    	public void visit(OWLObjectSomeValuesFrom desc) {
		    	System.out.println(desc);
		    	System.out.println(" " + getCurrentAxiom());
	    	}
    	};
    	// Have the walker walk...
    	walker.walkStructure(visitor);
    }

    //stampa su file le relazioni subClassOf
	public void printHierarchy() {
		OWLDataFactory df = m.getOWLDataFactory();
		OWLClass root = r.getTopClassNode().getRepresentativeElement();
		NodeSet<OWLClass> subClasses = r.getSubClasses(root, true);

		for (Node<OWLClass> subClassNode : subClasses) {
			for (OWLClass owlClass : subClassNode) {
				System.out.println(owlClass);
				subHierarchy(1,owlClass);
			}
		}
		System.out.println("Successfully wrote to the file.");
	}
	private void subHierarchy(int level, OWLClass root) {
		NodeSet<OWLClass> subClasses = r.getSubClasses(root, true);
		StringBuilder space = new StringBuilder(" ");
		for (int i = 0; i < level; i++)
			space.append("  ");
		OWLDataFactory df = m.getOWLDataFactory();
		for (Node<OWLClass> subClassNode : subClasses) {
			for (OWLClass owlClass : subClassNode) {
				Iterator<OWLClass> i = r.bottomClassNode().iterator();
				while(i.hasNext()) {
					 OWLClass next = i.next();
					 if( next == owlClass)
					 	return;
				}
				try {
					FileWriter myWriter = new FileWriter("src\\main\\resources\\subclassof.txt", true);
//					System.out.println(owlClass + " " + root);
					myWriter.write(owlClass + " " + root + "\n");
					myWriter.close();
				} catch (IOException e) {
					System.out.println("An error occurred.");
					e.printStackTrace();
				}
					subHierarchy(level+1, owlClass);
			}
		}
	}

}